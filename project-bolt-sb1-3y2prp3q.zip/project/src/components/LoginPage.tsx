import React from 'react';
import LoginForm from './LoginForm';
import Logo from './Logo';
import { useAuth } from '../utils/auth';

const LoginPage: React.FC = () => {
  const { login } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md animate-fadeIn">
        <div className="mb-10 flex justify-center">
          <Logo />
        </div>
        
        <LoginForm onLogin={login} />
        
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Staff portal access only.</p>
          <p className="mt-1">For patient inquiries, please call our helpline.</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;