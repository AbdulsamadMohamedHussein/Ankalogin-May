import React from 'react';
import { Heart } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center">
      <div className="bg-blue-600 p-2 rounded-lg shadow-md">
        <Heart className="h-8 w-8 text-white" fill="white" strokeWidth={2} />
      </div>
      <div className="ml-3">
        <h1 className="text-2xl font-bold text-gray-800">Anka Hospital</h1>
        <p className="text-sm text-gray-600">Caring for life</p>
      </div>
    </div>
  );
};

export default Logo;